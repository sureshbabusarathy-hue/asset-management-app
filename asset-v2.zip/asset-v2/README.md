# Naandi Asset Management System (asset-v2)

A web-based asset management system built for **Naandi Foundation** to track IT equipment, furniture, vehicles, machinery, and other organizational assets across multiple states, projects, and locations.

> **Tech stack:** Node.js · Express · MongoDB · Mongoose · JWT · Vanilla JS frontend with Chart.js

---

## Features

- **Asset lifecycle tracking** — record, assign, retire, and audit assets across categories (IT Equipment, Furniture, Vehicles, Machinery, Software Licenses, Office Equipment).
- **Assignment history** — every asset keeps a full history of who it was assigned to, when, and by whom.
- **Maintenance log** — schedule and track repairs, services, inspections, and upgrades with cost tracking.
- **Multi-level organization** — assets are organised by Project → State → Location → Department.
- **Role-based access** — JWT-authenticated users (Admin, Manager, Staff) with bcrypt-hashed passwords.
- **Account security** — request rate-limiting (`express-rate-limit`) and password hashing.
- **Dashboards & charts** — real-time overview of asset status, condition, and category distribution using Chart.js.

---

## Project Structure

```
asset-v2/
├── backend/
│   ├── controllers/      Asset, auth, project, user logic
│   ├── middleware/       JWT auth middleware
│   ├── models/           Mongoose schemas — Asset, User, Project, State, Location
│   ├── routes/           /api/auth, /api/assets, /api/projects, /api/users
│   ├── server.js         Express entry point
│   ├── setup.js          Initial DB seed
│   └── package.json
├── frontend/
│   └── index.html        Single-page app (vanilla JS + Chart.js)
├── start-app.bat         One-click startup script (Windows)
├── .env.example          Sample environment file
├── .gitignore
└── README.md
```

---

## Getting Started

### Prerequisites

| Tool    | Version |
|---------|---------|
| Node.js | 18+     |
| MongoDB | 6+      |
| npm     | 9+      |

### 1. Clone

```bash
git clone https://github.com/<your-username>/asset-v2.git
cd asset-v2
```

### 2. Install backend dependencies

```bash
cd backend
npm install
```

### 3. Configure environment

```bash
cp .env.example backend/.env
```

Then edit `backend/.env` and set your own `MONGODB_URI` and a strong `JWT_SECRET`.

### 4. Run

```bash
# Terminal 1 — MongoDB
mongod

# Terminal 2 — Backend (from /backend)
npm run dev      # http://localhost:5001

# Terminal 3 — Frontend (from /frontend)
npx http-server -p 3000
# open http://localhost:3000
```

---

## API Reference

### Auth
```
POST /api/auth/login        { email, password }  → { token, user }
POST /api/auth/register     Admin-only — create new users
GET  /api/auth/me           Current user (Bearer token)
```

### Assets
```
GET    /api/assets                  List assets (filter by status, project, etc.)
POST   /api/assets                  Create new asset
PUT    /api/assets/:id              Update asset
POST   /api/assets/:id/assign       Assign to user
POST   /api/assets/:id/return       Mark as returned
POST   /api/assets/:id/maintenance  Add maintenance record
DELETE /api/assets/:id              Retire asset
```

### Projects / States / Locations / Users
Standard REST CRUD endpoints with role-based authorization.

---

## Asset Schema Highlights

- `category` — IT Equipment, Furniture, Vehicle, Machinery, Software License, Office Equipment, Other
- `status` — available, assigned, maintenance, retired, lost
- `condition` — excellent, good, fair, poor
- `assignmentHistory[]` — full audit trail of assignments
- `maintenanceHistory[]` — every service/repair/inspection record

---

## Security Notes

- Passwords hashed with `bcryptjs` (10 rounds).
- JWT tokens expire in 24h.
- All `/api/*` routes are rate-limited (200 requests / 15 min per IP).
- Real `.env` file is excluded via `.gitignore`. Use `.env.example` as a template.

---

## Roadmap

- React frontend rewrite for richer UI
- Excel bulk-import for assets
- QR-code labels for physical asset tagging
- Email alerts for upcoming maintenance
- Mobile app for field staff to log asset transfers

---

## Author

Built by **Suresh Babu** for Naandi Foundation.
